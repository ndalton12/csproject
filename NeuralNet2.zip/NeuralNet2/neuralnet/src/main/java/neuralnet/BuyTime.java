package neuralnet;

import java.util.ArrayList;

public class BuyTime {
	
	public static void main (String [] args) {
		
	}

	public static String findBuyTime(String[] data) {
		String time = "";
		double minimum = 0;
		int position = -1;
		
			for (int i = data.length-1; i >= 0; i--) {
				if (i == data.length-1) {
					minimum = Double.parseDouble(data[i]);
					position = i;
				} else if (Double.parseDouble(data[i]) < minimum) {
					minimum = Double.parseDouble(data[i]);
					position = i;
				}
			}
		
		time = Double.toString(position);
		//System.out.println(minimum);
		return time;
	}
}
