package neuralnet;

public class DeleteFirstLast {
	
	public static String delFirstLast(String data) {
		data = data.substring(1,data.length()-1);
		return data;
	}

}
