package neuralnet;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import javax.swing.border.LineBorder;

import org.apache.commons.io.FileUtils;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.nd4j.linalg.api.ndarray.INDArray;
import org.nd4j.linalg.dataset.DataSet;

public class GUI {

	/*
	 * Instance variables for the GUI
	 */
	private JFrame frame;
	private JTextField textField;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField txtEnterDaysAway;

	static JPanel panel_3 = new JPanel();
	
	/*
	 * ArrayList to handle the data
	 */

	ArrayList<Double> data = new ArrayList<Double>();

	/*
	 * Getting the date
	 */
	Date date = new Date();
	static String timeStampYear = new SimpleDateFormat("yyyy").format(Calendar.getInstance().getTime());
	static String timeStampDay = new SimpleDateFormat("dd").format(Calendar.getInstance().getTime());
	static String timeStampMonth = new SimpleDateFormat("MM").format(Calendar.getInstance().getTime());

	/*
	 * More variables
	 */
	private static int daysAway;
	private static String maxPrice = "N/A";
	private static String minPrice = "N/A";
	private static String totalSell = "N/A";
	private static String timeBuy = "N/A";
	private static String timeSell = "N/A";

	private static String input_url = "";
	private static String stockName;
	private static String url;
	private static String directory;
	private static String datastuff;
	private static String[] dataArray;
	
	//private static int daysaway = 10;

	/*
	 * Main Method
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {

				System.out.println(timeStampYear);
				System.out.println(timeStampDay);
				System.out.println(timeStampMonth);

				try {
					GUI window = new GUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/*
	 * Creates the Application
	 */
	public GUI() {
		initialize();
	}

	/*
	 * Initializes contents of the frame
	 */
	private void initialize() {
		// INITIAL FRAME
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setBounds(100, 100, 600, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JLabel lblNewLabel = new JLabel("Stock Prediction Application");
		lblNewLabel.setBounds(6, 6, 200, 15);
		frame.getContentPane().add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("Developed by: Niall Dalton & John Ta");
		lblNewLabel_1.setFont(new Font("Lucida Grande", Font.PLAIN, 9));
		lblNewLabel_1.setBounds(6, 20, 200, 12);
		frame.getContentPane().add(lblNewLabel_1);

		JLabel lblNewLabel_2 = new JLabel("Stock Name:");
		lblNewLabel_2.setBounds(6, 49, 175, 16);
		frame.getContentPane().add(lblNewLabel_2);

		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel.setBackground(Color.GRAY);
		panel.setBounds(0, 35, 400, 3);
		frame.getContentPane().add(panel);

		textField = new JTextField("Enter stock name here");
		textField.setBounds(175, 44, 395, 26);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		textField.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				textField.setText("");
			}
		});
		JLabel lblTotalAmountOf = new JLabel("Total Days Away");
		lblTotalAmountOf.setBounds(6, 77, 175, 16);
		frame.getContentPane().add(lblTotalAmountOf);

		txtEnterDaysAway = new JTextField("Enter days away");
		txtEnterDaysAway.setColumns(10);
		txtEnterDaysAway.setBounds(175, 72, 395, 26);
		frame.getContentPane().add(txtEnterDaysAway);
		txtEnterDaysAway.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				txtEnterDaysAway.setText("");
			}
		});

		JLabel label = new JLabel("");
		label.setBounds(6, 105, 175, 16);
		frame.getContentPane().add(label);

		JPanel panel_2 = new JPanel();
		panel_2.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel_2.setBackground(Color.GRAY);
		panel_2.setBounds(0, 105, 400, 3);
		frame.getContentPane().add(panel_2);

		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel_1.setBackground(Color.GRAY);
		panel_1.setBounds(99, 161, 400, 3);
		frame.getContentPane().add(panel_1);

		JLabel lblMaximumPredictedPrice = new JLabel("Maximum Predicted Price:");
		lblMaximumPredictedPrice.setBounds(6, 181, 175, 16);
		frame.getContentPane().add(lblMaximumPredictedPrice);

		JLabel lblMinimumPredictedPrice = new JLabel("Minimum Predicted Price:");
		lblMinimumPredictedPrice.setBounds(6, 214, 175, 16);
		frame.getContentPane().add(lblMinimumPredictedPrice);

		JLabel lblPredictedBuyTime = new JLabel("Predicted Buy Time:");
		lblPredictedBuyTime.setBounds(6, 247, 175, 16);
		frame.getContentPane().add(lblPredictedBuyTime);

		JLabel lblPredictedSellTime = new JLabel("Predicted Sell Time:");
		lblPredictedSellTime.setBounds(6, 280, 175, 16);
		frame.getContentPane().add(lblPredictedSellTime);

		/*
		 * ANCHOR
		 */
		textField_2 = new JTextField(maxPrice);
		textField_2.setColumns(10);
		textField_2.setBounds(175, 176, 395, 26);
		frame.getContentPane().add(textField_2);
		textField_2.setEditable(false);

		textField_3 = new JTextField(minPrice);
		textField_3.setColumns(10);
		textField_3.setBounds(175, 209, 395, 26);
		frame.getContentPane().add(textField_3);
		textField_3.setEditable(false);

		textField_5 = new JTextField(timeBuy);
		textField_5.setColumns(10);
		textField_5.setBounds(175, 242, 395, 26);
		frame.getContentPane().add(textField_5);
		textField_5.setEditable(false);

		textField_6 = new JTextField(timeSell);
		textField_6.setColumns(10);
		textField_6.setBounds(175, 275, 395, 26);
		frame.getContentPane().add(textField_6);
		textField_6.setEditable(false);

		JButton btnPredictStockOutput = new JButton("Predict Stock Output");
		btnPredictStockOutput.addActionListener(new ActionListener() {

			@SuppressWarnings("static-access")
			public void actionPerformed(ActionEvent arg) {

				/*
				 * Try Statement
				 */
				try {
					/*
					 * Checks if the buttons are clicked and obtains the Strings
					 * for the name of the stock and the total funds
					 */
					if ((textField.getText()).isEmpty()) {
						System.exit(0);
					} else {
						stockName = textField.getText();
					}

					daysAway = (int)Math.round(Double.parseDouble(txtEnterDaysAway.getText()));

					/*
					 * Downloads the File from quandl with up to date year and
					 * month. ANCHOR
					 */

					input_url = "https://www.quandl.com/api/v3/datasets/WIKI/" + stockName + 
					        "/data.csv?column_index=4&exclude_column_names=true"; // updateqqqq
					url = input_url;

					/*
					 * Saves the file to a temporary file location in the
					 * computer
					 */

					ParseFile filer = new ParseFile(input_url);

					System.out.println(input_url); // removeqqq
					directory = filer.getPath();
					
					datastuff = Tester.potato();
					System.out.println("HONK: " + Tester.getPotato());
					datastuff = DeleteFirstLast.delFirstLast(datastuff);
					datastuff = DeleteFirstLast.delFirstLast(datastuff);
					dataArray = datastuff.split(",");
					
					/*
					 * Finds the maximum and minimum of the data
					 */
					
					//ANCHOR 2
					//System.out.println("Triggered: " + Arrays.toString(dataArray));
					//System.out.println("Triggered2: " + dataArray[5]);
					maxPrice = Double.toString(MaxPredictedValue.getMax(dataArray, daysAway));
					minPrice = Double.toString(MaxPredictedValue.getMin(dataArray, daysAway));

					//System.out.println("Max Price: " + maxPrice); // removeqqq
					//System.out.println("Min Price: " + minPrice); // removeqqq

					// Set the textfields for max and min
					textField_2.setText(maxPrice);
					textField_3.setText(minPrice);

					/*
					 * Finding the maximum amount to buy
					 */

					MaxBuy buy = new MaxBuy(daysAway, Double.parseDouble(minPrice));

					totalSell = buy.getMax();

					// Set the textfield for total to sell
					/*
					 * Find the buy time
					 */

					timeBuy = BuyTime.findBuyTime(dataArray);
					textField_5.setText(timeBuy);
					
					/*
					 * Find the sell time
					 */

					timeSell = SellTime.findSellTime(dataArray);
					textField_6.setText(timeSell);
					
					JPanel panel_object =  new ChartPanel(Tester.getChart());
					/*
					JFrame f = new JFrame();
					f.add(panel_object);
					f.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
					f.pack();
					f.setTitle("Training Data");
				
					f.setVisible(true);
					*/
					
					//panel_3 = Tester.getGraph();
					
					frame.setBounds(100, 100, 600, 600);
					
					panel_object.setBounds(16, 308, 554, 200);
					frame.getContentPane().add(panel_object);
					
					
					/*
					 * Catch Statement
					 */
				} catch (ArithmeticException e) {
					JOptionPane.showMessageDialog(null, "Error: Input is Empty!");
				} catch (Exception e) {
					JOptionPane.showMessageDialog(null, "Error");
				}
			}
		});
		btnPredictStockOutput.setBounds(200, 120, 200, 29);
		frame.getContentPane().add(btnPredictStockOutput);

		JTextArea textArea = new JTextArea();
		textArea.setBounds(257, 417, 1, 16);
		frame.getContentPane().add(textArea);
		
	}
	
	
	public static void setGraph(JPanel framed) {
		panel_3 = framed;
	}
}
