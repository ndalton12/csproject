package neuralnet;

public class MaxBuy {

	private static double totalFunds;
	private static double minPrice;
	private static double remainder = 0;
	private static double xPrice = 0;
	private static String totalSell;
	
	public MaxBuy (double totalFunds, double minPrice) {
		this.totalFunds = totalFunds;
		this.minPrice = minPrice;
		
		remainder = totalFunds % minPrice;
		
		System.out.println(remainder);
		
		double xPrice = totalFunds - remainder;
		System.out.println(xPrice);
		totalSell = Double.toString(xPrice / minPrice);
		totalSell = Long.toString(Math.round(Double.parseDouble(totalSell)));
	}
	
	public static String getMax() {
		return totalSell;
	}
	
	public static void setMax() {
		
		remainder = totalFunds % minPrice;
		
		double xPrice = totalFunds - remainder;
		System.out.println(xPrice);
		totalSell = Double.toString(xPrice / minPrice);
		totalSell = Long.toString(Math.round(Double.parseDouble(totalSell)));
	}
	
}
