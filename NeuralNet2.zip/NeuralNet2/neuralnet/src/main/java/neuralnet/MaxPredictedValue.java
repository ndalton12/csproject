package neuralnet;

import java.util.ArrayList;

public class MaxPredictedValue {

	public static void main(String [] args) {
		
		String[] billy = {"9.1","15.2", "16.1", "19.1","11.5"};
		
		System.out.println(getMax(billy, 4));
		System.out.println(getMin(billy, 4));
		//System.out.println(getMax(stuff));
		//System.out.println(getMin(stuff));
		
	}
	
	public static double getMax(String[] arraydata, int daysaway) {
		double max = 0;
		
		for (int x = daysaway-1; x >= 0; x--) {
			if (Double.parseDouble(arraydata[x]) > max) {
				max = Double.parseDouble(arraydata[x]);
			}
		}
		
		return max;
	}
	
	public static double getMin(String[] arraydata, int daysaway) {
		double min = getMax(arraydata, daysaway);
		
		for (int x = daysaway-1; x >= 0; x--) {
			if (Double.parseDouble(arraydata[x]) < min) {
				min = Double.parseDouble(arraydata[x]);
			}
		}
		
		return min;
	}
	
}
