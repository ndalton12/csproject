package neuralnet;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

import org.apache.commons.io.FileUtils;

public class ParseFile {

		private static String input_url = "";
		private static String directory = "";
		private static String url = "";
		
	public ParseFile(String input_url) throws Exception {
		this.input_url = input_url;
		url = input_url;
		
		url = input_url;
		File file = new File(input_url);
		String tempDir = System.getProperty("java.io.tmpdir");
		String fileLocation = tempDir + "/stockdata.csv";
		File f = new File(fileLocation);
		try {
			FileUtils.copyURLToFile(new URL(url), f);
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		System.out.println("File downloaded to " + f.getAbsolutePath());
		
		directory = f.getAbsolutePath();
		if (!f.exists())
		{
			try {
				throw new IOException("File does not exist: " + fileLocation);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		   Scanner main = new Scanner(f);

		    FileWriter replaced = new FileWriter(createReplacedCsv());

		    StringBuilder builder = new StringBuilder();

		    int line = 0;
		    int totalLines = 0;
		    CharSequence c = ".";
		    
		    while (main.hasNextLine() && !(main.nextLine().isEmpty())) {
		    	totalLines++;
		    	System.out.println("entered here - " + totalLines);
		    }
		    
		    main.close();
		    
		    main = new Scanner(f);
		    
		    while (main.hasNext()) {

		        String[] wordsInLine = main.nextLine().split(",");
		        for (String word : wordsInLine) {
		            if (!word.contains(c)) {
		                word = String.valueOf(totalLines - line);
		            }
		            builder.append(word).append(",");
		        }
		        line ++;
		        builder.deleteCharAt(builder.lastIndexOf(","));
		        builder.append("\n");
		    }

		    replaced.write(builder.toString());
		    replaced.close();
		    
		    main.close();
		    
		    System.out.println("Finished");
	}
	
	public static String getPath() {
		return directory;
	}
	
	public static void setPath(String input_url) {
		url = input_url;
		File file = new File(input_url);
		String tempDir = System.getProperty("java.io.tmpdir");
		String fileLocation = tempDir + "/stockdata.csv";
		File f = new File(fileLocation);
		try {
			FileUtils.copyURLToFile(new URL(url), f);
		} catch (MalformedURLException e) {
			e.printStackTrace();
			System.out.println("Error with copying URL");
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("Error with copying URL");
		}
		
		System.out.println("File downloaded to " + f.getAbsolutePath());
		
		directory = f.getAbsolutePath();
		if (!f.exists())
		{
			try {
				throw new IOException("File does not exist: " + fileLocation);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
	}
	
	private static File createReplacedCsv() throws Exception {
	    File replacedCsv = new File("replaced.csv");
	    replacedCsv.createNewFile();
	    return replacedCsv;
	}
	/*
	public static void main(String [] args) {
		String bob = "https://www.quandl.com/api/v3/datasets/WIKI/AAPL/data.csv?column_index=4&exclude_column_names=true&rows=3&start_date=2012-11-01&end_date=2017-01-01";
		setPath(bob);
		System.out.println(getPath());
	}
	*/
	
}
