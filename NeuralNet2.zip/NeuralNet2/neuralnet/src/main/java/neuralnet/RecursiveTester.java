package neuralnet;

public class RecursiveTester {
	/**
	 * A sample main method to be used for testing purposes
	 */
	public static void main(String[] args) {
		System.out.println("-1: " +evenProducts(-1));
		System.out.println("0: " +evenProducts(0));
		System.out.println("1: " + evenProducts(1));
		System.out.println("2: " + evenProducts(2));
		System.out.println("3: " +  evenProducts(3));
		System.out.println("4: " + evenProducts(4));
		System.out.println("8: " + evenProducts(8));
	}

	/**
	 * A recursive function that returns the product of the first n even
	 * integers * @param n the number of even integers
	 * 
	 * @return the product of the first n even integers, or 0 if n < 1
	 */
	public static int evenProducts(int n) {
		if (n < 0) {
			return 0;
		} 
		
		if (n == 1) {
			return 2;
		} else {
			return evenProducts(n-1) * (n*2);
		}
	
		//return product;
	}
}