package neuralnet;

import java.util.ArrayList;

public class SellTime {

	public static void main(String[] args) {
	
	}

	public static String findSellTime(String[] data) {
		String time = "-1";
		double maximum = 0;
		int position = -1;

		for (int i = data.length-1; i >= 0; i--) {
			if (i == data.length-1) {
				maximum = Double.parseDouble(data[i]);
				position = i;
			} else if (Double.parseDouble(data[i]) > maximum) {
				maximum = Double.parseDouble(data[i]);
				position = i;
			}
		}

		System.out.println(maximum);
		time = Double.toString(position);
		return time;
	}

}
