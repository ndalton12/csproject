package neuralnet;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.WindowConstants;

import org.apache.commons.io.FileUtils;
import org.datavec.api.records.reader.RecordReader;
import org.datavec.api.records.reader.SequenceRecordReader;
import org.datavec.api.records.reader.impl.csv.CSVRecordReader;
import org.datavec.api.records.reader.impl.csv.CSVSequenceRecordReader;
import org.datavec.api.split.FileSplit;
import org.datavec.api.split.NumberedFileInputSplit;
import org.deeplearning4j.datasets.datavec.RecordReaderDataSetIterator;
import org.deeplearning4j.datasets.datavec.SequenceRecordReaderDataSetIterator;
import org.deeplearning4j.eval.RegressionEvaluation;
import org.deeplearning4j.nn.api.Layer;
import org.deeplearning4j.nn.api.OptimizationAlgorithm;
import org.deeplearning4j.nn.conf.BackpropType;
import org.deeplearning4j.nn.conf.MultiLayerConfiguration;
import org.deeplearning4j.nn.conf.NeuralNetConfiguration;
import org.deeplearning4j.nn.conf.Updater;
import org.deeplearning4j.nn.conf.layers.GravesLSTM;
import org.deeplearning4j.nn.conf.layers.RnnOutputLayer;
import org.deeplearning4j.nn.multilayer.MultiLayerNetwork;
import org.deeplearning4j.nn.weights.WeightInit;
import org.deeplearning4j.optimize.listeners.ScoreIterationListener;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.nd4j.linalg.api.ndarray.INDArray;
import org.nd4j.linalg.dataset.DataSet;
import org.nd4j.linalg.dataset.api.iterator.DataSetIterator;
import org.nd4j.linalg.dataset.api.preprocessor.NormalizerMinMaxScaler;
import org.nd4j.linalg.factory.Nd4j;
import org.nd4j.linalg.lossfunctions.LossFunctions.LossFunction;

import scala.sys.process.ProcessBuilderImpl.FileInput;

public class Tester {
	
	// Hyper-parameters
	
	public static JFrame framey;
	public static final int miniBatchSize = 1;
	public static final int numPossibleLabels = -1;
	public static final int labelIndex = 1; // Zero indexed
	
	public static final int lstmLayerSize = 100;
	public static final int tbpttLength = 40; 
	
	public static final int numEpochs = 1;
	private static String dataset = "";
	
	static JPanel graph = new JPanel();
	static JFreeChart chart;
	
	static ArrayList<DataSet> DataSetList = new ArrayList<>();
	
    @SuppressWarnings("deprecation")
	public static String potato() throws Exception {
    	
    	int totalLines = 0;
    	int trainSize = 0;
    	int testSize = 0;
    	//ANCHOR 1 TOP
		String fileLocation = "replaced.csv";
		File f = new File(fileLocation);
		
		if (!f.exists())
			throw new IOException("File does not exist: " + fileLocation);
		
	    Scanner main = new Scanner(f);
	    
	    while (main.hasNextLine() && !(main.nextLine().isEmpty())) {
	    	totalLines++;
	    	//System.out.println("entered here - " + totalLines);
	    }
	    
	    main.close();
	    
	    trainSize = Math.round((float)0.75*totalLines);
	    testSize = totalLines - trainSize;
    	
    	Path rawPath = Paths.get("replaced.csv");

        List<String> rawStrings = Files.readAllLines(rawPath, Charset.defaultCharset());
        
        File baseDir = new File("data");
        
        FileUtils.cleanDirectory(baseDir);
        
        Path trainPath = Paths.get("data/quotes_0.csv");
        Path testPath = Paths.get("data/quotes_1.csv");
        
        for (int i = 0; i < trainSize; i++) {
        	Files.write(trainPath, rawStrings.get(i).concat(System.lineSeparator()).getBytes(), StandardOpenOption.APPEND, StandardOpenOption.CREATE);
        }
        
        for (int i = trainSize; i < testSize+trainSize; i++) {
        	Files.write(testPath, rawStrings.get(i).concat(System.lineSeparator()).getBytes(), StandardOpenOption.APPEND, StandardOpenOption.CREATE);
        }
        
        StringBuilder builder = new StringBuilder();
        FileWriter replace = new FileWriter(createQuoteCsv());

	    int line = 0;
	    File f2 = new File("data/quotes_0.csv");
	    CharSequence c = ".";
        
        main = new Scanner(f2);
	    
	    while (main.hasNext()) {

	        String[] wordsInLine = main.nextLine().split(",");
	        for (String word : wordsInLine) {
	            if (!word.contains(c)) {
	                word = String.valueOf(trainSize - line);
	            }
	            builder.append(word).append(",");
	        }
	        line ++;
	        builder.deleteCharAt(builder.lastIndexOf(","));
	        builder.append("\n");
	    }

	    replace.write(builder.toString());
	    replace.close();
	    
	    main.close();
    	//ANCHOR 1 BOTTOM
    	SequenceRecordReader reader = new CSVSequenceRecordReader(0, ",");
    	//reader.initialize(new NumberedFileInputSplit("C:/Users/Niall/Desktop/NeuralNet/quotes_%d.csv", 0, 0));
    	reader.initialize(new NumberedFileInputSplit("data/quotes_%d.csv", 2, 2));
    	DataSetIterator iter = new SequenceRecordReaderDataSetIterator(reader, miniBatchSize, numPossibleLabels, labelIndex, true);
    	
    	SequenceRecordReader reader2 = new CSVSequenceRecordReader(0, ",");
    	//reader2.initialize(new NumberedFileInputSplit("C:/Users/Niall/Desktop/NeuralNet/quotes_%d.csv", 1, 1));
    	reader2.initialize(new NumberedFileInputSplit("data/quotes_%d.csv", 1, 1));
    	DataSetIterator iter2 = new SequenceRecordReaderDataSetIterator(reader2, miniBatchSize, numPossibleLabels, labelIndex, true);
    	
    	
    	int nOut = iter.inputColumns();
    	
    	MultiLayerConfiguration conf = new NeuralNetConfiguration.Builder()
    			.optimizationAlgo(OptimizationAlgorithm.STOCHASTIC_GRADIENT_DESCENT).iterations(2)
    			.learningRate(0.01) // 0.0001
    			.rmsDecay(0.95)
    			.seed(54321)
    			.regularization(true)
    			.l2(0.001)
                .weightInit(WeightInit.SIZE) // Previously WeightInit.XAVIER
                .updater(Updater.RMSPROP)
    			.list()
    			.layer(0, new GravesLSTM.Builder().nIn(iter.inputColumns()).nOut(lstmLayerSize)
    					.activation("tanh").build())
    			.layer(1, new GravesLSTM.Builder().nIn(lstmLayerSize).nOut(lstmLayerSize)
    					.activation("tanh").build())
    			.layer(2, new RnnOutputLayer.Builder(LossFunction.MSE).activation("identity")
    					.nIn(lstmLayerSize).nOut(nOut).build())
                .backpropType(BackpropType.TruncatedBPTT).tBPTTForwardLength(tbpttLength).tBPTTBackwardLength(tbpttLength)
    			.pretrain(false).backprop(true)
    			.build();

		MultiLayerNetwork net = new MultiLayerNetwork(conf);
		net.init();
		net.setListeners(new ScoreIterationListener(1));
		
		Layer[] layers = net.getLayers();
		int totalNumParams = 0;
		
		for( int i = 0; i < layers.length; i++){
			int nParams = layers[i].numParams();
			System.out.println("Number of parameters in layer " + i + ": " + nParams);
			totalNumParams += nParams;
		}
		
		System.out.println("Total number of network parameters: " + totalNumParams);
		
		INDArray output = Nd4j.zeros(1);
		INDArray predicted = Nd4j.zeros(1);
		
        for( int i = 0; i < numEpochs; i++) {
        	net.fit(iter);
        	iter.reset();
        	
        	RegressionEvaluation eval = new RegressionEvaluation(1);
        	
        	while (iter2.hasNext()) {
        		DataSet ds = iter2.next();
        		INDArray features = ds.getFeatureMatrix();
                INDArray labels = ds.getLabels();
                predicted = net.output(features,false);
                output = predicted;
                System.out.println(predicted);
                eval.evalTimeSeries(labels,predicted);
                
                System.out.println(String.format("Standardized Prediction:  %s, Standardized Actual: %s", 
                        predicted.toString(), labels.toString()));
                
        	} //ANCHOR
        	
        	//System.out.println(eval.stats());

            iter2.reset();
        }
        
        while (iter.hasNext()) {
            DataSet t = iter.next();
            net.rnnTimeStep(t.getFeatureMatrix());
        }

        iter.reset();
        
		System.out.println("\n\nFinished");
		
		
		// ***************************************************** New stuff
		
		String filename = "data/quotes_1.csv";
    	DataSet ds = readCSVDataset(filename);

    	NormalizerMinMaxScaler preProcessor = new NormalizerMinMaxScaler();
    	
    	DataSetList.add(ds);
    	preProcessor.fit(ds);
        int nSamples = 23;
    	INDArray x = Nd4j.linspace(preProcessor.getMin().getInt(0),preProcessor.getMax().getInt(0),nSamples).reshape(nSamples, 1);
    	DataSet ds2 = new DataSet(x,output);
    	DataSetList.add(ds2);
    	
    	//JPanel graph = new ChartPanel(PlotDataSet.plotDataset(DataSetList)); 
    	//JFrame framey = new JFrame();
    	//framey.add(graph);
    	//framey.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    	//framey.pack();
    	//framey.setTitle("Training Data");
	
    	//framey.setVisible(true);
    	
    	setVars(DataSetList, PlotDataSet.plotDataset(DataSetList));
    	
    	dataset = predicted.toString();
    	return predicted.toString();
    }
   
    public static void setVars (ArrayList<DataSet> DataSetList, JFreeChart chart) {
		Tester.DataSetList = DataSetList;
		Tester.chart = chart;
		//this.graph = graph;
	}

	public static JPanel getGraph () {
    	
    	return graph;
    }
    public static String getPotato() {
    	return dataset;
    }
    
    public static JFreeChart getChart() {
    	return chart;
    }
    
    private static DataSet readCSVDataset(String filename) throws IOException, InterruptedException {
		int batchSize = 1000;
		RecordReader rr = new CSVRecordReader();
		rr.initialize(new FileSplit(new File(filename)));
		
		DataSetIterator iter =  new RecordReaderDataSetIterator(rr,batchSize, 1, 1, true);
		return iter.next();
	}
    
    private static File createQuoteCsv() throws Exception {
	    File replacedCsv = new File("data/quotes_2.csv");
	    replacedCsv.createNewFile();
	    return replacedCsv;
	}
    
   // public static JPanel getGraph() {
    //	return panel;
    //}
}

