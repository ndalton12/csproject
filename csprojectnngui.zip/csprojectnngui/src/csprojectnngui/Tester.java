package csprojectnngui;

import org.datavec.api.records.reader.SequenceRecordReader;
import org.datavec.api.records.reader.impl.csv.CSVSequenceRecordReader;
import org.datavec.api.split.NumberedFileInputSplit;
import org.deeplearning4j.datasets.datavec.SequenceRecordReaderDataSetIterator;
import org.deeplearning4j.eval.Evaluation;
import org.deeplearning4j.nn.api.Layer;
import org.deeplearning4j.nn.api.OptimizationAlgorithm;
import org.deeplearning4j.nn.conf.BackpropType;
import org.deeplearning4j.nn.conf.ComputationGraphConfiguration;
import org.deeplearning4j.nn.conf.MultiLayerConfiguration;
import org.deeplearning4j.nn.conf.NeuralNetConfiguration;
import org.deeplearning4j.nn.conf.Updater;
import org.deeplearning4j.nn.conf.graph.rnn.DuplicateToTimeSeriesVertex;
import org.deeplearning4j.nn.conf.graph.rnn.LastTimeStepVertex;
import org.deeplearning4j.nn.conf.inputs.InputType;
import org.deeplearning4j.nn.conf.layers.GravesLSTM;
import org.deeplearning4j.nn.conf.layers.RnnOutputLayer;
import org.deeplearning4j.nn.graph.ComputationGraph;
import org.deeplearning4j.nn.multilayer.MultiLayerNetwork;
import org.deeplearning4j.nn.weights.WeightInit;
import org.deeplearning4j.optimize.listeners.ScoreIterationListener;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.nd4j.linalg.api.buffer.DataBuffer;
import org.nd4j.linalg.api.buffer.util.DataTypeUtil;
import org.nd4j.linalg.api.ndarray.INDArray;
import org.nd4j.linalg.dataset.DataSet;
import org.nd4j.linalg.dataset.api.MultiDataSet;
import org.nd4j.linalg.dataset.api.iterator.DataSetIterator;
import org.nd4j.linalg.factory.Nd4j;
import org.nd4j.linalg.lossfunctions.LossFunctions;
import org.nd4j.linalg.lossfunctions.LossFunctions.LossFunction;
import org.deeplearning4j.optimize.listeners.ScoreIterationListener;

import java.util.ArrayList;
import java.util.logging.Logger;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.WindowConstants;

public class Tester {
	
	// Hyper-parameters
	
	public static final int miniBatchSize = 1;
	public static final int numPossibleLabels = -1;
	public static final int labelIndex = 0; // Zero index
	
	public static final int lstmLayerSize = 200;
	public static final int tbpttLength = 50; 
	
	public static final int numEpochs = 10;
	public static final int plotFrequency = 2;

	public static String location = "/var/folders/px/qxxxkkf94vb78m930nmyglr00000gp/T/stockdata.csv";
	
	public static void setLocation(String loc) {
		location = loc;
	}
	
	public static String getLocation() {
		return location;
	}
	
    public static void main(String[] args) throws Exception {
		generator();
    }
    
    public static void generator() throws Exception {
   	SequenceRecordReader reader = new CSVSequenceRecordReader(0, ",");
    	
    	System.out.println(location);
    	reader.initialize(new NumberedFileInputSplit(getLocation() , 2, 2));
    	
    	DataSetIterator iter = new SequenceRecordReaderDataSetIterator(reader, miniBatchSize, numPossibleLabels, labelIndex, true);
    	int nOut = iter.totalOutcomes();
    	
    	MultiLayerConfiguration conf = new NeuralNetConfiguration.Builder()
    			.optimizationAlgo(OptimizationAlgorithm.STOCHASTIC_GRADIENT_DESCENT).iterations(1)
    			.learningRate(0.1)
    			.rmsDecay(0.95)
    			.seed(12345)
    			.regularization(true)
    			.l2(0.001)
                .weightInit(WeightInit.XAVIER)
                .updater(Updater.RMSPROP)
    			.list()
    			.layer(0, new GravesLSTM.Builder().nIn(iter.inputColumns()).nOut(lstmLayerSize)
    					.activation("tanh").build())
    			.layer(1, new GravesLSTM.Builder().nIn(lstmLayerSize).nOut(lstmLayerSize)
    					.activation("tanh").build())
    			.layer(2, new RnnOutputLayer.Builder(LossFunction.MCXENT).activation("softmax")        //MCXENT + softmax for classification
    					.nIn(lstmLayerSize).nOut(nOut).build())
                .backpropType(BackpropType.TruncatedBPTT).tBPTTForwardLength(tbpttLength).tBPTTBackwardLength(tbpttLength)
    			.pretrain(false).backprop(true)
    			.build();

		MultiLayerNetwork net = new MultiLayerNetwork(conf);
		net.init();
		net.setListeners(new ScoreIterationListener(1));
		
		Layer[] layers = net.getLayers();
		int totalNumParams = 0;
		
		for( int i = 0; i < layers.length; i++){
			int nParams = layers[i].numParams();
			System.out.println("Number of parameters in layer " + i + ": " + nParams);
			totalNumParams += nParams;
		}
		
		System.out.println("Total number of network parameters: " + totalNumParams);
		
        for( int i = 0; i < numEpochs; i++) {
            
            
            
            Evaluation evaluation = new Evaluation();
            
            while(iter.hasNext()){
            	net.fit(iter);
                DataSet t = iter.next();
                INDArray features = t.getFeatureMatrix();
                INDArray lables = t.getLabels();
                INDArray inMask = t.getFeaturesMaskArray();
                INDArray outMask = t.getLabelsMaskArray();
                INDArray predicted = net.output(features,false,inMask,outMask);

                evaluation.evalTimeSeries(lables,predicted,outMask);
            }
            iter.reset();

            System.out.println(evaluation.stats(true));

        }

		System.out.println("\n\nFinished");
    }
    
    private static void plot(final INDArray x, final INDArray... predicted) {
        final XYSeriesCollection dataSet = new XYSeriesCollection();

        for( int i = 0; i < predicted.length; i++ ){
            addSeries(dataSet,x,predicted[i],String.valueOf(i));
            //System.out.println(predicted[i]);
        }

        final JFreeChart chart = ChartFactory.createXYLineChart(
                "Regression Example",      // chart title
                "X",                        // x axis label
                "(Other)", // y axis label
                dataSet,                    // data
                PlotOrientation.VERTICAL,
                true,                       // include legend
                true,                       // tooltips
                false                       // urls
        );

        final ChartPanel panel = new ChartPanel(chart);

        final JFrame f = new JFrame();
        f.add(panel);
        f.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        f.pack();

        f.setVisible(true);
    }
    
    private static void addSeries(final XYSeriesCollection dataSet, final INDArray x, final INDArray y, final String label){
        final double[] xd = x.data().asDouble();
        final double[] yd = y.data().asDouble();
        final XYSeries s = new XYSeries(label);
        for( int j=0; j<xd.length; j++ ) s.add(xd[j],yd[j]);
        dataSet.addSeries(s);
    }
    
    private static int findIndexOfHighestValue(double[] distribution) {
		int maxValueIndex = 0;
		double maxValue = 0;
		for (int i = 0; i < distribution.length; i++) {
			if(distribution[i] > maxValue) {
				maxValue = distribution[i];
				maxValueIndex = i;
			}
		}
		return maxValueIndex;
	}
}

