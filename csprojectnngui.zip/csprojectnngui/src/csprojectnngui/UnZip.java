package csprojectnngui;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import org.apache.commons.io.FileUtils;

public class UnZip {
	List<String> fileList;
	private static String INPUT_ZIP_FILE = "http://www.colorado.edu/conflict/peace/download/peace_essay.ZIP";
	public String pineapple = "";
	private static String OUTPUT_FOLDER = "";

	public static void main(String[] args) {
		File desktopDir = new File(System.getProperty("user.home"), "Desktop");
		File f = new File(""+desktopDir+"/csvdata");
		System.out.println(""+desktopDir);
		try {
			FileUtils.copyURLToFile(new URL(INPUT_ZIP_FILE), f);
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		INPUT_ZIP_FILE = "" + desktopDir + "/csvdata";
		
		System.out.println(INPUT_ZIP_FILE);
		UnZip unZip = new UnZip();
		unZip.unZipIt(INPUT_ZIP_FILE, OUTPUT_FOLDER);
	}

	/**
	 * Unzip it
	 * 
	 * @param zipFile
	 *            input zip file
	 * @param output
	 *            zip file output folder
	 */
	public String unZipIt(String zipFile, String outputFolder) {

		byte[] buffer = new byte[1024];
		
		try {

			// create output directory is not exists
			File folder = new File(OUTPUT_FOLDER);
			if (!folder.exists()) {
				folder.mkdir();
			}

			// get the zip file content
			ZipInputStream zis = new ZipInputStream(new FileInputStream(zipFile));
			// get the zipped file list entry
			ZipEntry ze = zis.getNextEntry();

			while (ze != null) {

				String fileName = ze.getName();
				File newFile = new File(outputFolder + File.separator + fileName);

				System.out.println("file unzip : " + newFile.getAbsoluteFile());
				pineapple = "" + newFile.getAbsoluteFile();
				
				// create all non exists folders
				// else you will hit FileNotFoundException for compressed folder
				new File(newFile.getParent()).mkdirs();

				//FileOutputStream fos = new FileOutputStream(newFile);

				/*int len;
				while ((len = zis.read(buffer)) > 0) {
					fos.write(buffer, 0, len);
				}

				fos.close();*/
				ze = zis.getNextEntry();
			}

			zis.closeEntry();
			zis.close();

		} catch (IOException ex) {
			ex.printStackTrace();
		}
		System.out.println(pineapple);
		return pineapple;
	}
	
}